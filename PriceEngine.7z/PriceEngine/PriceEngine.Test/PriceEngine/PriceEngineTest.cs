﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using PriceEngine.Business.Services;
using PriceEngine.Business.Interfaces;
using PriceEngine.Business.Models;
using PriceEngine.Business.Utilities;

namespace PriceEngine.Test.PriceEngine
{
    [TestClass]
    public class PriceEngineTest
    {
        [TestMethod]
        public void GetRecommendedPrice_Positive_Test()
        {  
            List<decimal> lstResults = new List<decimal>();
            lstResults.Add(0.9M);
            lstResults.Add(10.5M);          
            var priceEngineResponse = new PriceEngineResponse();
            priceEngineResponse.RecommendedPrice = lstResults;
            priceEngineResponse.ResultStatus = PriceEngineResponse.Status.Success.ToString();
            priceEngineResponse.ResultMessage = PriceEngineMessage.OutputMessage;

            //Arrange            
            var inputs = new List<string>();
            inputs.Add("2");
            inputs.Add("flashdrive H H");
            inputs.Add("ssd L H");
            inputs.Add("5");
            inputs.Add("flashdrive X 1.0");
            inputs.Add("ssd X 10.0");
            inputs.Add("flashdrive X 0.9");
            inputs.Add("flashdrive X 1.1");
            inputs.Add("ssd X 12.5");

            var priceEngineReq = new PriceEngineRequest()
            {
                NoOfProduct = 2,
                NoOfSurveyedData = 5,
                RawProductData = "",
                RawSurveyedData = "",
                ProductList = new List<Product>()
                {
                    new Product()
                    {
                            ProductId = 1,
                            ProductName = "flashdrive",
                            Supply = "H",
                            Demand = "H"
                    },
                     new Product()
                    {
                            ProductId = 2,
                            ProductName = "ssd",
                            Supply = "L",
                            Demand = "H"
                     }
                },
                SurveyedDataList = new List<SurveyedData>()
                {
                    new SurveyedData()
                    {
                          ProductId = 1,
                          ProductName = "flashdrive",
                          CompetitorPrice = 1.0M
                    },
                     new SurveyedData()
                    {
                          ProductId = 2,
                          ProductName = "ssd",
                          CompetitorPrice = 10.0M
                    },
                      new SurveyedData()
                    {
                          ProductId = 1,
                          ProductName = "flashdrive",
                          CompetitorPrice = 0.9M
                    },
                       new SurveyedData()
                    {
                          ProductId = 1,
                          ProductName = "flashdrive",
                          CompetitorPrice = 1.1M
                    },
                        new SurveyedData()
                    {
                          ProductId = 2,
                          ProductName = "ssd",
                          CompetitorPrice = 12.5M
                    }
                }
            };


            Mock<IPriceEngine> mockIPriceEngine = new Mock<IPriceEngine>();

            //Act
            mockIPriceEngine.Setup(x => x.GetProductRequest(It.IsAny<List<string>>())).Returns(priceEngineReq);            
            mockIPriceEngine
                .Setup(x => x.GenerateResults(It.IsAny<List<SurveyedData>>(), It.IsAny<List<Product>>()))
                .Returns(lstResults);
            mockIPriceEngine.Setup(x => x.BuildPriceResponse(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<List<decimal>>())).Returns(priceEngineResponse);

            PriceEngineBuilder priceEngine = new PriceEngineBuilder(mockIPriceEngine.Object);
            var priceResult = priceEngine.GetRecommendedPrice(inputs);

            //Assert
            Assert.AreEqual(priceResult.ResultStatus, priceEngineResponse.ResultStatus);
            CollectionAssert.AreEquivalent(priceResult.RecommendedPrice, priceEngineResponse.RecommendedPrice);
        }

        [TestMethod]
        public void Should_Thrown_Exception_When_NoOfProduct_AsZero()
        {
            List<decimal> lstResults = new List<decimal>();           
            var priceEngineResponse = new PriceEngineResponse();
            priceEngineResponse.RecommendedPrice = lstResults;
            priceEngineResponse.ResultStatus = PriceEngineResponse.Status.Failure.ToString();
            priceEngineResponse.ResultMessage = PriceEngineMessage.NoOfproductVal;

            //Arrange            
            var inputs = new List<string>();
            inputs.Add("0");            

            var priceEngineReq = new PriceEngineRequest()
            {  };


            Mock<IPriceEngine> mockIPriceEngine = new Mock<IPriceEngine>();

            //Act
            mockIPriceEngine.Setup(x => x.GetProductRequest(It.IsAny<List<string>>())).Returns(priceEngineReq);
            mockIPriceEngine
                .Setup(x => x.GenerateResults(It.IsAny<List<SurveyedData>>(), It.IsAny<List<Product>>()))
                .Returns(lstResults);
            mockIPriceEngine.Setup(x => x.BuildPriceResponse(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<List<decimal>>())).Returns(priceEngineResponse);

            PriceEngineBuilder priceEngine = new PriceEngineBuilder(mockIPriceEngine.Object);
            var priceResult = priceEngine.GetRecommendedPrice(inputs);

            //Assert
            Assert.AreEqual(priceResult.ResultStatus, priceEngineResponse.ResultStatus);
            Assert.AreEqual(priceResult.ResultMessage, priceEngineResponse.ResultMessage);           
        }

        [TestMethod]
        public void Should_Thrown_Exception_When_NoOfProduct_As_Non_Numeric()
        {
            List<decimal> lstResults = new List<decimal>();
            var priceEngineResponse = new PriceEngineResponse();
            priceEngineResponse.RecommendedPrice = lstResults;
            priceEngineResponse.ResultStatus = PriceEngineResponse.Status.Failure.ToString();
            priceEngineResponse.ResultMessage = PriceEngineMessage.ProductNumeric;

            //Arrange            
            var inputs = new List<string>();
            inputs.Add("A");

            var priceEngineReq = new PriceEngineRequest()
            { };


            Mock<IPriceEngine> mockIPriceEngine = new Mock<IPriceEngine>();

            //Act
            mockIPriceEngine.Setup(x => x.GetProductRequest(It.IsAny<List<string>>())).Returns(priceEngineReq);
            mockIPriceEngine
                .Setup(x => x.GenerateResults(It.IsAny<List<SurveyedData>>(), It.IsAny<List<Product>>()))
                .Returns(lstResults);
            mockIPriceEngine.Setup(x => x.BuildPriceResponse(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<List<decimal>>())).Returns(priceEngineResponse);

            PriceEngineBuilder priceEngine = new PriceEngineBuilder(mockIPriceEngine.Object);
            var priceResult = priceEngine.GetRecommendedPrice(inputs);

            //Assert
            Assert.AreEqual(priceResult.ResultStatus, priceEngineResponse.ResultStatus);
            Assert.AreEqual(priceResult.ResultMessage, priceEngineResponse.ResultMessage);
        }

        [TestMethod]
        public void Should_Thrown_Exception_When_Incorrect_Product_Format()
        {
            List<decimal> lstResults = new List<decimal>();
            var priceEngineResponse = new PriceEngineResponse();
            priceEngineResponse.RecommendedPrice = lstResults;
            priceEngineResponse.ResultStatus = PriceEngineResponse.Status.Failure.ToString();
            priceEngineResponse.ResultMessage = PriceEngineMessage.ProductMissVal;

            //Arrange            
            var inputs = new List<string>();
            inputs.Add("2");
            inputs.Add("flashdrive H H");
            inputs.Add("ssd L");         

            var priceEngineReq = new PriceEngineRequest()
            { };


            Mock<IPriceEngine> mockIPriceEngine = new Mock<IPriceEngine>();

            //Act
            mockIPriceEngine.Setup(x => x.GetProductRequest(It.IsAny<List<string>>())).Returns(priceEngineReq);
            mockIPriceEngine
                .Setup(x => x.GenerateResults(It.IsAny<List<SurveyedData>>(), It.IsAny<List<Product>>()))
                .Returns(lstResults);
            mockIPriceEngine.Setup(x => x.BuildPriceResponse(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<List<decimal>>())).Returns(priceEngineResponse);

            PriceEngineBuilder priceEngine = new PriceEngineBuilder(mockIPriceEngine.Object);
            var priceResult = priceEngine.GetRecommendedPrice(inputs);

            //Assert
            Assert.AreEqual(priceResult.ResultStatus, priceEngineResponse.ResultStatus);
            Assert.AreEqual(priceResult.ResultMessage, priceEngineResponse.ResultMessage);
        }

        [TestMethod]
        public void Should_Thrown_Exception_When_Incorrect_ProductSupplyDemand()
        {
            List<decimal> lstResults = new List<decimal>();
            var priceEngineResponse = new PriceEngineResponse();
            priceEngineResponse.RecommendedPrice = lstResults;
            priceEngineResponse.ResultStatus = PriceEngineResponse.Status.Failure.ToString();
            priceEngineResponse.ResultMessage = PriceEngineMessage.ProductSupplyDemand;

            //Arrange            
            var inputs = new List<string>();
            inputs.Add("2");
            inputs.Add("flashdrive H H");
            inputs.Add("ssd L N");

            var priceEngineReq = new PriceEngineRequest(){ };

            Mock<IPriceEngine> mockIPriceEngine = new Mock<IPriceEngine>();

            //Act
            mockIPriceEngine.Setup(x => x.GetProductRequest(It.IsAny<List<string>>())).Returns(priceEngineReq);
            mockIPriceEngine
                .Setup(x => x.GenerateResults(It.IsAny<List<SurveyedData>>(), It.IsAny<List<Product>>()))
                .Returns(lstResults);
            mockIPriceEngine.Setup(x => x.BuildPriceResponse(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<List<decimal>>())).Returns(priceEngineResponse);

            PriceEngineBuilder priceEngine = new PriceEngineBuilder(mockIPriceEngine.Object);
            var priceResult = priceEngine.GetRecommendedPrice(inputs);

            //Assert
            Assert.AreEqual(priceResult.ResultStatus, priceEngineResponse.ResultStatus);
            Assert.AreEqual(priceResult.ResultMessage, priceEngineResponse.ResultMessage);
        }

        [TestMethod]
        public void Should_Thrown_Exception_When_Duplicate_Product()
        {
            List<decimal> lstResults = new List<decimal>();
            var priceEngineResponse = new PriceEngineResponse();
            priceEngineResponse.RecommendedPrice = lstResults;
            priceEngineResponse.ResultStatus = PriceEngineResponse.Status.Failure.ToString();
            priceEngineResponse.ResultMessage = PriceEngineMessage.DuplicateProduct;

            //Arrange            
            var inputs = new List<string>();
            inputs.Add("2");
            inputs.Add("ssd H H");
            inputs.Add("ssd L L");

            var priceEngineReq = new PriceEngineRequest(){ };
            Mock<IPriceEngine> mockIPriceEngine = new Mock<IPriceEngine>();

            //Act
            mockIPriceEngine.Setup(x => x.GetProductRequest(It.IsAny<List<string>>())).Returns(priceEngineReq);
            mockIPriceEngine
                .Setup(x => x.GenerateResults(It.IsAny<List<SurveyedData>>(), It.IsAny<List<Product>>()))
                .Returns(lstResults);
            mockIPriceEngine.Setup(x => x.BuildPriceResponse(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<List<decimal>>())).Returns(priceEngineResponse);

            PriceEngineBuilder priceEngine = new PriceEngineBuilder(mockIPriceEngine.Object);
            var priceResult = priceEngine.GetRecommendedPrice(inputs);

            //Assert
            Assert.AreEqual(priceResult.ResultStatus, priceEngineResponse.ResultStatus);
            Assert.AreEqual(priceResult.ResultMessage, priceEngineResponse.ResultMessage);
        }

        [TestMethod]
        public void Should_Thrown_Exception_When_ProductNumber_And_ProductList_Mismatch()
        {
            List<decimal> lstResults = new List<decimal>();
            var priceEngineResponse = new PriceEngineResponse();
            priceEngineResponse.RecommendedPrice = lstResults;
            priceEngineResponse.ResultStatus = PriceEngineResponse.Status.Failure.ToString();
            priceEngineResponse.ResultMessage = PriceEngineMessage.ProductNoMismatch;

            //Arrange            
            var inputs = new List<string>();
            inputs.Add("2");
            inputs.Add("ssd H H");
            inputs.Add("headphone L L");
            inputs.Add("ssd L L");

            var priceEngineReq = new PriceEngineRequest() { };
            Mock<IPriceEngine> mockIPriceEngine = new Mock<IPriceEngine>();

            //Act
            mockIPriceEngine.Setup(x => x.GetProductRequest(It.IsAny<List<string>>())).Returns(priceEngineReq);
            mockIPriceEngine
                .Setup(x => x.GenerateResults(It.IsAny<List<SurveyedData>>(), It.IsAny<List<Product>>()))
                .Returns(lstResults);
            mockIPriceEngine.Setup(x => x.BuildPriceResponse(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<List<decimal>>())).Returns(priceEngineResponse);

            PriceEngineBuilder priceEngine = new PriceEngineBuilder(mockIPriceEngine.Object);
            var priceResult = priceEngine.GetRecommendedPrice(inputs);

            //Assert
            Assert.AreEqual(priceResult.ResultStatus, priceEngineResponse.ResultStatus);
            Assert.AreEqual(priceResult.ResultMessage, priceEngineResponse.ResultMessage);
        }

        [TestMethod]
        public void Should_Thrown_Exception_When_NoOfSurveyedData_LessThan_ProductList()
        {
            List<decimal> lstResults = new List<decimal>();
            var priceEngineResponse = new PriceEngineResponse();
            priceEngineResponse.RecommendedPrice = lstResults;
            priceEngineResponse.ResultStatus = PriceEngineResponse.Status.Failure.ToString();
            priceEngineResponse.ResultMessage = PriceEngineMessage.NoOfSurveyedDataVal;

            //Arrange            
            var inputs = new List<string>();
            inputs.Add("2");
            inputs.Add("flashdrive H H");
            inputs.Add("ssd L H");
            inputs.Add("1");
            inputs.Add("flashdrive X 1.0");

            var priceEngineReq = new PriceEngineRequest() { };
            Mock<IPriceEngine> mockIPriceEngine = new Mock<IPriceEngine>();

            //Act
            mockIPriceEngine.Setup(x => x.GetProductRequest(It.IsAny<List<string>>())).Returns(priceEngineReq);
            mockIPriceEngine
                .Setup(x => x.GenerateResults(It.IsAny<List<SurveyedData>>(), It.IsAny<List<Product>>()))
                .Returns(lstResults);
            mockIPriceEngine.Setup(x => x.BuildPriceResponse(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<List<decimal>>())).Returns(priceEngineResponse);

            PriceEngineBuilder priceEngine = new PriceEngineBuilder(mockIPriceEngine.Object);
            var priceResult = priceEngine.GetRecommendedPrice(inputs);

            //Assert
            Assert.AreEqual(priceResult.ResultStatus, priceEngineResponse.ResultStatus);
            Assert.AreEqual(priceResult.ResultMessage, priceEngineResponse.ResultMessage);
        }

        [TestMethod]
        public void Should_Thrown_Exception_When_SurveyedData_Incorrect_Format()
        {
            List<decimal> lstResults = new List<decimal>();
            var priceEngineResponse = new PriceEngineResponse();
            priceEngineResponse.RecommendedPrice = lstResults;
            priceEngineResponse.ResultStatus = PriceEngineResponse.Status.Failure.ToString();
            priceEngineResponse.ResultMessage = PriceEngineMessage.SurveyedMissVal;

            //Arrange            
            var inputs = new List<string>();
            inputs.Add("2");
            inputs.Add("flashdrive H H");
            inputs.Add("ssd L H");
            inputs.Add("3");
            inputs.Add("flashdrive Y 1.0");
            inputs.Add("ssd X 10.0");
            inputs.Add("flashdrive X");            

            var priceEngineReq = new PriceEngineRequest() { };
            Mock<IPriceEngine> mockIPriceEngine = new Mock<IPriceEngine>();

            //Act
            mockIPriceEngine.Setup(x => x.GetProductRequest(It.IsAny<List<string>>())).Returns(priceEngineReq);
            mockIPriceEngine
                .Setup(x => x.GenerateResults(It.IsAny<List<SurveyedData>>(), It.IsAny<List<Product>>()))
                .Returns(lstResults);
            mockIPriceEngine.Setup(x => x.BuildPriceResponse(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<List<decimal>>())).Returns(priceEngineResponse);

            PriceEngineBuilder priceEngine = new PriceEngineBuilder(mockIPriceEngine.Object);
            var priceResult = priceEngine.GetRecommendedPrice(inputs);

            //Assert
            Assert.AreEqual(priceResult.ResultStatus, priceEngineResponse.ResultStatus);
            Assert.AreEqual(priceResult.ResultMessage, priceEngineResponse.ResultMessage);
        }

        [TestMethod]
        public void Should_Thrown_Exception_When_SurveyedData_Price_Incorrect_Format()
        {
            List<decimal> lstResults = new List<decimal>();
            var priceEngineResponse = new PriceEngineResponse();
            priceEngineResponse.RecommendedPrice = lstResults;
            priceEngineResponse.ResultStatus = PriceEngineResponse.Status.Failure.ToString();
            priceEngineResponse.ResultMessage = PriceEngineMessage.SurveyedDataPrice;

            //Arrange            
            var inputs = new List<string>();
            inputs.Add("2");
            inputs.Add("flashdrive H H");
            inputs.Add("ssd L H");
            inputs.Add("3");
            inputs.Add("flashdrive Y 1.0");
            inputs.Add("ssd X 10.0");
            inputs.Add("flashdrive X X");

            var priceEngineReq = new PriceEngineRequest() { };
            Mock<IPriceEngine> mockIPriceEngine = new Mock<IPriceEngine>();

            //Act
            mockIPriceEngine.Setup(x => x.GetProductRequest(It.IsAny<List<string>>())).Returns(priceEngineReq);
            mockIPriceEngine
                .Setup(x => x.GenerateResults(It.IsAny<List<SurveyedData>>(), It.IsAny<List<Product>>()))
                .Returns(lstResults);
            mockIPriceEngine.Setup(x => x.BuildPriceResponse(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<List<decimal>>())).Returns(priceEngineResponse);

            PriceEngineBuilder priceEngine = new PriceEngineBuilder(mockIPriceEngine.Object);
            var priceResult = priceEngine.GetRecommendedPrice(inputs);

            //Assert
            Assert.AreEqual(priceResult.ResultStatus, priceEngineResponse.ResultStatus);
            Assert.AreEqual(priceResult.ResultMessage, priceEngineResponse.ResultMessage);
        }

        [TestMethod]
        public void Should_Thrown_Exception_When_SurveyedData_And_SurveyedList_Mismatch()
        {
            List<decimal> lstResults = new List<decimal>();
            var priceEngineResponse = new PriceEngineResponse();
            priceEngineResponse.RecommendedPrice = lstResults;
            priceEngineResponse.ResultStatus = PriceEngineResponse.Status.Failure.ToString();
            priceEngineResponse.ResultMessage = PriceEngineMessage.SurveyedNoMismatch;

            //Arrange            
            var inputs = new List<string>();
            inputs.Add("2");
            inputs.Add("flashdrive H H");
            inputs.Add("ssd L H");
            inputs.Add("3");
            inputs.Add("flashdrive Y 1.0");
            inputs.Add("ssd X 10.0");
            inputs.Add("flashdrive X 2.0");
            inputs.Add("ssd X 10.4");

            var priceEngineReq = new PriceEngineRequest() { };
            Mock<IPriceEngine> mockIPriceEngine = new Mock<IPriceEngine>();

            //Act
            mockIPriceEngine.Setup(x => x.GetProductRequest(It.IsAny<List<string>>())).Returns(priceEngineReq);
            mockIPriceEngine
                .Setup(x => x.GenerateResults(It.IsAny<List<SurveyedData>>(), It.IsAny<List<Product>>()))
                .Returns(lstResults);
            mockIPriceEngine.Setup(x => x.BuildPriceResponse(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<List<decimal>>())).Returns(priceEngineResponse);

            PriceEngineBuilder priceEngine = new PriceEngineBuilder(mockIPriceEngine.Object);
            var priceResult = priceEngine.GetRecommendedPrice(inputs);

            //Assert
            Assert.AreEqual(priceResult.ResultStatus, priceEngineResponse.ResultStatus);
            Assert.AreEqual(priceResult.ResultMessage, priceEngineResponse.ResultMessage);
        }

        [TestMethod]
        public void Should_Thrown_Exception_When_SurveyedProduct_Name_And_ProductName_Mismatch()
        {
            List<decimal> lstResults = new List<decimal>();
            var priceEngineResponse = new PriceEngineResponse();
            priceEngineResponse.RecommendedPrice = lstResults;
            priceEngineResponse.ResultStatus = PriceEngineResponse.Status.Failure.ToString();
            priceEngineResponse.ResultMessage = PriceEngineMessage.SurveyedDataNotMatch;

            //Arrange            
            var inputs = new List<string>();
            inputs.Add("2");
            inputs.Add("flashdrive H H");
            inputs.Add("ssd L H");
            inputs.Add("3");
            inputs.Add("flashdrive Y 1.0");
            inputs.Add("ssd X 10.0");
            inputs.Add("ssd X 2.0");           

            var priceEngineReq = new PriceEngineRequest() { };
            Mock<IPriceEngine> mockIPriceEngine = new Mock<IPriceEngine>();

            //Act
            mockIPriceEngine.Setup(x => x.GetProductRequest(It.IsAny<List<string>>())).Returns(priceEngineReq);
            mockIPriceEngine
                .Setup(x => x.GenerateResults(It.IsAny<List<SurveyedData>>(), It.IsAny<List<Product>>()))
                .Returns(lstResults);
            mockIPriceEngine.Setup(x => x.BuildPriceResponse(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<List<decimal>>())).Returns(priceEngineResponse);

            PriceEngineBuilder priceEngine = new PriceEngineBuilder(mockIPriceEngine.Object);
            var priceResult = priceEngine.GetRecommendedPrice(inputs);

            //Assert
            Assert.AreEqual(priceResult.ResultStatus, priceEngineResponse.ResultStatus);
            Assert.AreEqual(priceResult.ResultMessage, priceEngineResponse.ResultMessage);
        }
    }
}
