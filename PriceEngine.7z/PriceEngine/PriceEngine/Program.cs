﻿using PriceEngine.Business.Services;
using PriceEngine.Business.Interfaces;
using PriceEngine.Business.Models;
using PriceEngine.Business.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PriceEngine
{
    public class Program
    {        
        public static void Main(string[] args)
        {
            List<string> priceEngineinputs = new List<string>();

            Console.WriteLine(PriceEngineMessage.InputMessage);

            while (true)
            {
                var priceInput = Console.ReadLine();

                if (priceInput == PriceEngineMessage.Delimiter)
                    break;

                priceEngineinputs.Add(priceInput);
            }

            try
            {
                IPriceEngine priceEngine = new PriceEngineUtility();
                PriceEngineBuilder priceBuilder = new PriceEngineBuilder(priceEngine);
                var priceResponse = priceBuilder.GetRecommendedPrice(priceEngineinputs);
                
                if(priceResponse.ResultStatus == PriceEngineResponse.Status.Success.ToString())
                {
                    Console.WriteLine(priceResponse.ResultMessage);
                    foreach (var response in priceResponse.RecommendedPrice)
                    {
                        Console.WriteLine(response);
                    }
                }
                else if (priceResponse.ResultStatus == PriceEngineResponse.Status.Failure.ToString())
                {
                    Console.WriteLine(priceResponse.ResultMessage);
                }
                else
                {
                    Console.WriteLine(PriceEngineMessage.InternalError);
                }
               
            }
            catch (Exception e)
            {
                Console.WriteLine(PriceEngineMessage.InternalError + e.StackTrace);
            }
        }        
    }
}
