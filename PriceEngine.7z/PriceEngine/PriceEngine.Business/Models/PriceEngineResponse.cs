﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PriceEngine.Business.Models
{
    public class PriceEngineResponse
    {
       public List<decimal> RecommendedPrice { get; set; }

        public enum Status
        {
            Success,
            Failure
        }
        public string ResultMessage { get; set; }
        public string ResultStatus { get; set; }
    }
}
