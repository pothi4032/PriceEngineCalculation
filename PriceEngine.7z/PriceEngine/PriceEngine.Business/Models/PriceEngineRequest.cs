﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PriceEngine.Business.Models
{
    public class PriceEngineRequest
    {
        public int NoOfProduct { get; set; }
        public int NoOfSurveyedData { get; set; }
        public string RawProductData { get; set; }
        public string RawSurveyedData { get; set; }
        public List<Product> ProductList { get; set; }
        public List<SurveyedData> SurveyedDataList { get; set; }
    }
}
