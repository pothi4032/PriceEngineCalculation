﻿using PriceEngine.Business.Interfaces;
using PriceEngine.Business.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PriceEngine.Business.Utilities
{
    public class PriceEngineUtility: IPriceEngine
    {
        //Get product and surveyed data from user input
        public PriceEngineRequest GetProductRequest(List<string> priceInput)
        {
            var priceEngReq = ProcessPriceInput(priceInput);
            PriceEngineRequest request = new PriceEngineRequest();           
           
            List<Product> lstProduct = new List<Product>();
            var productRows = priceEngReq.RawProductData.Split(new[] { Environment.NewLine }, StringSplitOptions.None);
            if(Convert.ToInt32(productRows[0]) != productRows.Length - 2)
                throw new Exception(PriceEngineMessage.ProductNoMismatch);
            for (int i = 0; i < productRows.Length - 1; i++)
            {
                var splitProducts = productRows[i].Split(null);
                if (i == 0)
                {
                    request.NoOfProduct = Convert.ToInt32(splitProducts[0]);
                    if (request.NoOfProduct <= 0)
                        throw new Exception(PriceEngineMessage.NoOfproductVal);
                }
                else
                {
                    if (splitProducts.Length == 3)
                    {
                        if((splitProducts[1].ToUpper() == "H" || splitProducts[1].ToUpper() == "L") && (splitProducts[2].ToUpper() == "H" || splitProducts[2].ToUpper() == "L"))
                        {
                            var productDetails = new Product();
                            productDetails.ProductId = i;
                            productDetails.ProductName = splitProducts[0];
                            productDetails.Supply = splitProducts[1].ToUpper();
                            productDetails.Demand = splitProducts[2].ToUpper();
                            lstProduct.Add(productDetails);
                        }
                        else
                           throw new Exception(PriceEngineMessage.ProductSupplyDemand);

                    }
                    else
                       throw new Exception(PriceEngineMessage.ProductMissVal);
                }
                
            }
            var anyDuplicateProduct = lstProduct.GroupBy(x => x.ProductName).Any(g => g.Count() > 1);
            if(anyDuplicateProduct)
                throw new Exception(PriceEngineMessage.DuplicateProduct);
            request.ProductList = lstProduct;

            var surveyedRows = priceEngReq.RawSurveyedData.ToString().Split(new[] { Environment.NewLine }, StringSplitOptions.None);
            if (Convert.ToInt32(surveyedRows[0]) != surveyedRows.Length - 2)
                throw new Exception(PriceEngineMessage.SurveyedNoMismatch);
            List<SurveyedData> lstSurveyedData = new List<SurveyedData>();
            for (int i = 0; i < surveyedRows.Length - 1; i++)
            {
                var splitProducts = surveyedRows[i].Split(null);                

                if (i == 0)
                {
                    request.NoOfSurveyedData = Convert.ToInt32(splitProducts[0]);
                    if (request.NoOfSurveyedData < request.NoOfProduct)
                        throw new Exception(PriceEngineMessage.NoOfSurveyedDataVal);
                }
                else
                {                    
                    if (splitProducts.Length == 3)
                    {
                        var productDataList = request.ProductList.Where(x => x.ProductName.ToUpper() == splitProducts[0].ToUpper()).ToList();
                        if (productDataList.Count == 0)
                            throw new Exception(PriceEngineMessage.SurveyedDataNotMatch);
                        if (decimal.TryParse(splitProducts[2], out decimal inputValue))
                        {
                            var productDetails = new SurveyedData();
                            productDetails.ProductId = Convert.ToInt32(productDataList[0].ProductId);
                            productDetails.ProductName = splitProducts[0];
                            productDetails.CompetitorPrice = Convert.ToDecimal(splitProducts[2]);
                            lstSurveyedData.Add(productDetails);
                        }
                        else
                            throw new Exception(PriceEngineMessage.SurveyedDataPrice);

                    }
                    else
                        throw new Exception(PriceEngineMessage.SurveyedMissVal);
                }
               
            }
            request.SurveyedDataList = lstSurveyedData;
            return request;
        }

        //Generated final resulsts
        public List<decimal> GenerateResults(List<SurveyedData> surveyedList, List<Product> proList)
        {
            List<decimal> lstResults = new List<decimal>();           

            var surveyedProduct = new Dictionary<string, List<SurveyedData>>();
            for (int j = 0; j < proList.Count; j++)
            {
                surveyedProduct["product" + j] = surveyedList.Where(x => x.ProductId == proList[j].ProductId).OrderBy(x => x.CompetitorPrice).ToList();

                decimal averagePrice = surveyedProduct["product" + j].Select(x => x.CompetitorPrice).Average();
                decimal currentCompetitorPrice;
                decimal leastPrice;
                List<decimal> actualPrices = new List<decimal>();
                var resultList = new List<SurveyedData>();
                for (int i = 0; i < surveyedProduct["product" + j].Count; i++)
                {
                    //Check Average price Rule
                    if (surveyedProduct["product" + j][i].CompetitorPrice < averagePrice / 2)
                    {
                        surveyedProduct["product" + j][i].isIgnore = true;
                    }
                    leastPrice = surveyedProduct["product" + j][0].CompetitorPrice;

                    //Check Frequently occuring price                                
                    currentCompetitorPrice = surveyedProduct["product" + j][i].CompetitorPrice;
                    if (!actualPrices.Contains(currentCompetitorPrice))
                        actualPrices.Add(currentCompetitorPrice);
                    else
                    {
                        if (leastPrice < currentCompetitorPrice)
                        {
                            surveyedProduct["product" + j][0].isIgnore = true;
                        }
                    }                 
                }
                //Apply supply and demand discounts for chosen product price 
                resultList = surveyedProduct["product" + j].Where(x => x.isIgnore == false).ToList();
                decimal recommendedPrice = CalculatePrice(resultList[0].CompetitorPrice, proList[j].Supply, proList[j].Demand);
                lstResults.Add(recommendedPrice);
            }
           
            return lstResults;            
        }

        //To calculation recommended price
        public decimal CalculatePrice(decimal price, string supply, string demand)
        {
            decimal recommendedPrice = 0;

            if (supply == PriceEngineMessage.HighSupplyDemand && demand == PriceEngineMessage.HighSupplyDemand)
                recommendedPrice = price;
            else if (supply == PriceEngineMessage.LowSupplyDemand && demand == PriceEngineMessage.LowSupplyDemand)
                recommendedPrice = price + (price * 10) / 100;
            else if (supply == PriceEngineMessage.LowSupplyDemand && demand == PriceEngineMessage.HighSupplyDemand)
                recommendedPrice = price + (price * 5) / 100;
            else if (supply == PriceEngineMessage.HighSupplyDemand && demand == PriceEngineMessage.LowSupplyDemand)
                recommendedPrice = price - (price * 5) / 100;

            return recommendedPrice;
        }

        //Generate price engine resonse with messages
        public PriceEngineResponse BuildPriceResponse(string status, string message, List<decimal> response = null)
        {
            PriceEngineResponse priceResponse = new PriceEngineResponse();
            priceResponse.ResultMessage = message;
            priceResponse.ResultStatus = PriceEngineResponse.Status.Success.ToString();
            priceResponse.RecommendedPrice = response;
            return priceResponse;
        }

        //To process user input
        public PriceEngineRequest ProcessPriceInput(List<string> priceInput)
        {
            PriceEngineRequest request = new PriceEngineRequest();
            StringBuilder productBuilder = new StringBuilder();
            StringBuilder surveyedDataBuilder = new StringBuilder();

            bool productData = false;
            int inputCount = 0; int priceEngineCount = 0;

            for (int i = 0; i < priceInput.Count; i++)
            {
                if (int.TryParse(priceInput[i], out int inputValue))
                {                  
                    if (i == 0)
                    {
                        productData = true;
                        productBuilder.AppendLine(priceInput[i]);
                    }
                    else
                    {
                        productData = false;
                        surveyedDataBuilder.AppendLine(priceInput[i]);
                    }
                    inputCount = inputValue;
                }
                else
                {
                    if (i == 0 && !productData)
                        throw new Exception(PriceEngineMessage.ProductNumeric);
                    else if (productData)
                        productBuilder.AppendLine(priceInput[i]);
                    else
                        surveyedDataBuilder.AppendLine(priceInput[i]);
                    priceEngineCount++;
                }
            }
            request.RawProductData = productBuilder.ToString();
            request.RawSurveyedData = surveyedDataBuilder.ToString();
            return request;
        }
    }
       
}
