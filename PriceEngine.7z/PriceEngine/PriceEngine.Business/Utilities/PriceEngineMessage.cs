﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PriceEngine.Business.Utilities
{
    public static class PriceEngineMessage
    {
        public static string InputMessage = "Please provide the price engine inputs end with '$'";
        public static string InternalError = "Internal Error Occured ";
        public static string OutputMessage = "Recommended price - Output";
        public static string HighSupplyDemand = "H";
        public static string LowSupplyDemand = "L";
        public static string Delimiter = "$";

        public static string NoOfproductVal = "Number of product must be greater than zero";
        public static string ProductNumeric = "Product/Surveyed number must be numeric";
        public static string ProductMissVal = "Please enter product name, supply and demand values as follows - SSD H L";
        public static string ProductSupplyDemand = "Please enter product supply and demand values as follows H(High) Or L(Low)";
        public static string DuplicateProduct = "Product name must be unique";
        public static string ProductNoMismatch = "Number of product and product details must be match";

        public static string NoOfSurveyedDataVal = "Number of Surveyed product input must be greater than or equal to number of product";
        public static string SurveyedMissVal = "Please enter product name, surveyed and competitor price value as like - SSD X 10.0";
        public static string SurveyedDataPrice = "Please enter competitor prices as like - 10.0";
        public static string SurveyedNoMismatch = "Number of Surveyed product and Surveyed details must be match";
        public static string SurveyedDataNotMatch = "Surveyed product name must match with above given product(s)";
    }
}
