﻿using PriceEngine.Business.Interfaces;
using PriceEngine.Business.Models;
using PriceEngine.Business.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PriceEngine.Business.Services
{
    public class PriceEngineBuilder
    {
        private readonly IPriceEngine _priceEngine;

        public PriceEngineBuilder(IPriceEngine priceEngine)
        {
            _priceEngine = priceEngine;
        }

        public PriceEngineResponse GetRecommendedPrice(List<string> priceInput)
        {
            try
            {
                var priceEngineRequest = _priceEngine.GetProductRequest(priceInput);
                               
                var priceEngineResults = _priceEngine.GenerateResults(priceEngineRequest.SurveyedDataList, priceEngineRequest.ProductList);

                var priceResponse =  _priceEngine.BuildPriceResponse(PriceEngineResponse.Status.Success.ToString(), PriceEngineMessage.OutputMessage, priceEngineResults);               
                return priceResponse;

            }
            catch (Exception e)
            {
                _priceEngine.BuildPriceResponse(PriceEngineResponse.Status.Failure.ToString(), e.Message);
                Console.WriteLine(PriceEngineMessage.InternalError +"- "+ e.Message);
                Console.ReadLine();
            }
            return null;
        }
       
    }
}
