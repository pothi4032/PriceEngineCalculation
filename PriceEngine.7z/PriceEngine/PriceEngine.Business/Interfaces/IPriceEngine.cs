﻿using PriceEngine.Business.Models;
using PriceEngine.Business.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PriceEngine.Business.Interfaces
{
    public interface IPriceEngine
    {
        PriceEngineRequest GetProductRequest(List<string> priceInput);
        List<decimal> GenerateResults(List<SurveyedData> surveyedList, List<Product> proList);
        decimal CalculatePrice(decimal price, string supply, string demand);
        PriceEngineResponse BuildPriceResponse(string status, string message, List<decimal> response = null);
        PriceEngineRequest ProcessPriceInput(List<string> priceInput);
    }
}
